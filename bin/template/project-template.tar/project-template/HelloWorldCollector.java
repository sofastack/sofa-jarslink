package com.mybank.bkcommon.collector.${package_name}.collector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.mybank.bkcommon.collector.core.CollectorTemplate;
import com.mybank.bkcommon.collector.core.Task;
import com.mybank.bkcommon.collector.${package_name}.model.HelloWorld;
import com.alipay.common.tracer.context.AbstractLogContext;
import com.alipay.common.tracer.context.RpcLogContext;
import com.alipay.common.tracer.tracer.Tracer;
import com.alipay.common.tracer.util.TraceIdGenerator;
import com.alipay.fc.common.lang.event.EventContext;
import com.alipay.fc.common.lang.event.EventContextUtil;
import com.mybank.bkcommon.model.Result;
import com.mybank.bkcommon.sdk.Category;
import org.apache.commons.lang.StringUtils;
import com.mybank.bkdmc.common.service.facade.TitanObjectKey;
import com.mybank.bkdmc.common.service.facade.TitanService;
import com.mybank.bkdmc.common.service.facade.annotation.Categorized;
import com.mybank.bkdmc.common.service.facade.request.GetObjectRequest;
import com.mybank.bkdmc.common.service.facade.response.GetObjectResponse;

/**
 * 访问地址如下：
 * 
 * <pre>
 * <a href="http://localhost:7777/data/${package_name}/default/helloworld/process.json">获取JSON数据</a>
 * <a href="http://localhost:7777/data/${package_name}/default/helloworld/view.htm">访问界面</a>
 * <a href="http://localhost:7777/data/${package_name}/default/helloworld/process.json?_callback=aaa">获取JSONP数据</a>
 * </pre>
 *
 */
@Categorized("helloworld")
public class HelloWorldCollector extends CollectorTemplate<HelloWorld> {

    private static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldCollector.class);

    private TitanService        titanService;

    /** 
     * @see com.mybank.bkcommon.collector.core.CollectorTemplate#doCollect(com.mybank.bkcommon.collector.core.Task)
     */
    @Override
    protected HelloWorld doCollect(Task task) {
        //调用tr接口 GET OBJECT
        GetObjectRequest getObjectRequest = new GetObjectRequest();
        TitanObjectKey objectKey = new TitanObjectKey();
        objectKey.setCategory(Category.POSEIDON_NOTES);
        objectKey.setEntityCode("2343545465656534545B");
        objectKey.setEntityType(TitanObjectKey.ENTITY_TYPE_LOAN);
        getObjectRequest.setObjectKey(objectKey);
        //系统名，正式使用需要改
        getObjectRequest.setSource("test");
        setTntInstId("MYBKC1CN");
        Result<GetObjectResponse> object = titanService.getObject(getObjectRequest);
        HelloWorld helloWorld = new HelloWorld();
        helloWorld.setHello("你好！");
        helloWorld.setWord("tr 调用结果：" + object.isSuccess() + "");
        helloWorld.setTr(object.isSuccess() + "");

        return helloWorld;
    }

    private void setTntInstId(String intInstId) {

        try {
            if (AbstractLogContext.get() == null) {
                RpcLogContext rpcLogContext = new RpcLogContext();
                rpcLogContext.setTraceId(TraceIdGenerator.generate());
                rpcLogContext.setRpcId(Tracer.ROOT_RPC_ID);
                rpcLogContext.setCallerApp("bkdmc");
                AbstractLogContext.set(rpcLogContext);
            }
        } catch (Exception ex) {
            LOGGER.error("获取线程变量失败!", ex);
        }
        // 初始化租户id 
        try {
            EventContext eventContext = EventContextUtil.getEventContextFromTracer();
            // 如果未设置租户id, 则设置银行租户id
            if (StringUtils.isBlank(eventContext.getTntInstId())) {
                eventContext.setTntInstId(intInstId);
                EventContextUtil.saveEventContextToTracer(eventContext);
            }
        } catch (Exception ex) {
            LOGGER.error("初始化租户ID失败!", ex);
            throw new RuntimeException("初始化租户ID失败!", ex);
        }
    }

    public void setTitanService(TitanService titanService) {
        this.titanService = titanService;
    }

}
