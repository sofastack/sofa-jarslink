package com.mybank.bkcommon.collector.${package_name}.model;

import com.mybank.bkcommon.collector.BaseModel;
import com.mybank.bkdmc.common.service.facade.annotation.Categorized;

@Categorized("${package_name}")
public class HelloWorld extends BaseModel {

    private String hello;

    private String word;

    private String tr;

    private String content;

    public String getHello() {
        return hello;
    }

    public void setHello(String hello) {
        this.hello = hello;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getTr() {
        return tr;
    }

    public void setTr(String tr) {
        this.tr = tr;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
