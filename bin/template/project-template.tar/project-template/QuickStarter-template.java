package com.mybank.bkcommon.collector.${package_name};

import com.mybank.bkcommon.collector.starter.CollectorStarter;

/**
 * 访问地址如下：
 * 
 * <pre>
 * <a href="http://localhost:7777/data/demo/default/helloworld/process.json">获取JSON数据</a>
 * <a href="http://localhost:7777/data/demo/default/helloworld/view.htm">访问界面</a>
 * <a href="http://localhost:7777/data/demo/default/helloworld/process.json?_callback=aaa">获取JSONP数据</a>
 * </pre>
 *
 */
public class QuickStarter extends CollectorStarter {

    /** 需要加载的spring配置文件 */
    private static final String[] locations = { "/META-INF/spring/*.xml", "integration-test.xml" };

    public QuickStarter(int port, String[] locations) {
        super(port, locations);
    }

    public static void main(String[] args) throws Throwable {
            new QuickStarter(7777, locations).run();
    }

}
